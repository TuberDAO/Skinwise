"use strict";exports.id=678,exports.ids=[678],exports.modules={57149:(e,t,n)=>{n.d(t,{sl:()=>A,xy:()=>S,jC:()=>D});var r=Object.defineProperty,i=Object.defineProperties,s=Object.getOwnPropertyDescriptors,o=Object.getOwnPropertySymbols,a=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=(e,t,n)=>t in e?r(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,c=(e,t)=>{for(var n in t||(t={}))a.call(t,n)&&d(e,n,t[n]);if(o)for(var n of o(t))l.call(t,n)&&d(e,n,t[n]);return e},u=(e,t)=>i(e,s(t)),m=(e,t,n)=>new Promise((r,i)=>{var s=e=>{try{a(n.next(e))}catch(e){i(e)}},o=e=>{try{a(n.throw(e))}catch(e){i(e)}},a=e=>e.done?r(e.value):Promise.resolve(e.value).then(s,o);a((n=n.apply(e,t)).next())}),p=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return m(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},h=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return m(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function f(e){return{attachments:e.attachments,bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var g=class{constructor(e){this.resend=e}send(e){return m(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return m(this,arguments,function*(e,t={}){let r=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield n.e(44).then(n.bind(n,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}r.push(f(t))}return yield this.resend.post("/emails/batch",r,t)})}},y=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield n.e(44).then(n.bind(n,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return m(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return m(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return m(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},b=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return m(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},w=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return m(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return m(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return m(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},v=class{constructor(e){this.resend=e}send(e){return m(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return m(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield n.e(44).then(n.bind(n,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",f(e),t)})}get(e){return m(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return m(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return m(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},x="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",k="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.6.0";let T=new class{constructor(e){if(this.key=e,this.apiKeys=new p(this),this.audiences=new h(this),this.batch=new g(this),this.broadcasts=new y(this),this.contacts=new b(this),this.domains=new w(this),this.emails=new v(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":k,"Content-Type":"application/json"})}fetchRequest(e){return m(this,arguments,function*(e,t={}){try{let n=yield fetch(`${x}${e}`,t);if(!n.ok)try{let e=yield n.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:n.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:u(c({},e),{message:t.message})};return{data:null,error:e}}return{data:yield n.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return m(this,arguments,function*(e,t,n={}){let r=new Headers(this.headers);n.idempotencyKey&&r.set("Idempotency-Key",n.idempotencyKey);let i=c({method:"POST",headers:r,body:JSON.stringify(t)},n);return this.fetchRequest(e,i)})}get(e){return m(this,arguments,function*(e,t={}){let n=c({method:"GET",headers:this.headers},t);return this.fetchRequest(e,n)})}put(e,t){return m(this,arguments,function*(e,t,n={}){let r=c({method:"PUT",headers:this.headers,body:JSON.stringify(t)},n);return this.fetchRequest(e,r)})}patch(e,t){return m(this,arguments,function*(e,t,n={}){let r=c({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},n);return this.fetchRequest(e,r)})}delete(e,t){return m(this,null,function*(){let n={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,n)})}}(process.env.RESEND_API_KEY);async function S(e){try{console.log("\uD83D\uDCE7 Sending assessment confirmation email to:",e.customerEmail);let{data:t,error:n}=await T.emails.send({from:"SkinWise <noreply@skinwise.com>",to:[e.customerEmail],subject:"✅ Your Skin Assessment Has Been Submitted - SkinWise",html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assessment Confirmed - SkinWise</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #0f766e, #0d9488); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .logo { font-size: 28px; font-weight: bold; margin-bottom: 10px; }
    .content { background: white; padding: 30px; border: 1px solid #e5e7eb; }
    .footer { background: #f8fafc; padding: 20px; text-align: center; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
    .highlight { background: #ecfdf5; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; border-radius: 4px; }
    .button { display: inline-block; background: #0f766e; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 500; margin: 15px 0; }
    .payment-details { background: #f1f5f9; padding: 15px; border-radius: 6px; margin: 15px 0; }
    .reference { font-family: monospace; background: #f3f4f6; padding: 8px; border-radius: 4px; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">SkinWise</div>
      <p style="margin: 0; opacity: 0.9;">Smart Skin Diagnostics</p>
    </div>
    
    <div class="content">
      <h1 style="color: #0f766e; margin-top: 0;">✅ Your Skin Assessment is Confirmed!</h1>
      
      <p>Hello ${e.customerName||"there"},</p>
      
      <p>Thank you for choosing SkinWise for your skin health assessment. We've successfully received your payment and your submission is now being processed by our team.</p>
      
      <div class="highlight">
        <h3 style="margin-top: 0; color: #059669;">What happens next?</h3>
        <ul style="margin-bottom: 0;">
          <li><strong>AI Analysis:</strong> Your photos and description are being analyzed by our advanced AI system</li>
          <li><strong>Professional Review:</strong> A qualified healthcare professional will review the AI analysis</li>
          <li><strong>Report Delivery:</strong> You'll receive a detailed PDF report via email within 24 hours</li>
          <li><strong>Referral Letter:</strong> If needed, we'll include a referral letter for your dermatologist</li>
        </ul>
      </div>
      
      <div class="payment-details">
        <h3 style="margin-top: 0;">Payment Details</h3>
        <p><strong>Amount Paid:</strong> ${e.currency} ${e.amount}</p>
        <p><strong>Payment Date:</strong> ${e.submissionDate}</p>
        <p><strong>Reference:</strong> <span class="reference">${e.sessionId}</span></p>
      </div>
      
      <p><strong>Important:</strong> Please check your spam folder if you don't receive your report within 24 hours. Our reports are sent from <code>noreply@skinwise.com</code>.</p>
      
      <p>If you have any questions or concerns, please don't hesitate to contact our support team.</p>
      
      <p>Best regards,<br>The SkinWise Team</p>
    </div>
    
    <div class="footer">
      <p style="margin: 0; color: #6b7280; font-size: 14px;">
        This email was sent to ${e.customerEmail}<br>
        SkinWise - Professional AI-Assisted Skin Health Analysis<br>
        If you need help, reply to this email or contact us directly.
      </p>
    </div>
  </div>
</body>
</html>
  `,text:`
SkinWise - Assessment Confirmation

Hello ${e.customerName||"there"},

Your skin assessment has been successfully submitted and payment confirmed!

WHAT HAPPENS NEXT:
- AI Analysis: Your photos are being analyzed by our advanced AI system
- Professional Review: A qualified healthcare professional will review the analysis
- Report Delivery: You'll receive a detailed PDF report within 24 hours
- Referral Letter: We'll include a referral letter for your dermatologist if needed

PAYMENT DETAILS:
Amount Paid: ${e.currency} ${e.amount}
Payment Date: ${e.submissionDate}
Reference: ${e.sessionId}

IMPORTANT: Check your spam folder if you don't receive your report within 24 hours.

Questions? Reply to this email or contact our support team.

Best regards,
The SkinWise Team

---
This email was sent to ${e.customerEmail}
SkinWise - Professional AI-Assisted Skin Health Analysis
  `});if(n)throw console.error("❌ Failed to send assessment confirmation email:",n),n;return console.log("✅ Assessment confirmation email sent successfully:",t?.id),{success:!0,messageId:t?.id}}catch(e){return console.error("❌ Error sending assessment confirmation email:",e),{success:!1,error:e}}}async function A(e){try{console.log("\uD83D\uDCE7 Sending appointment confirmation email to:",e.customerEmail);let{data:t,error:n}=await T.emails.send({from:"SkinWise <noreply@skinwise.com>",to:[e.customerEmail],subject:"\uD83E\uDE7A Your Dermatologist Appointment is Confirmed - SkinWise",html:function(e){let t=new Date(`${e.appointmentDate}T${e.appointmentTime}`).toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});return`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Appointment Confirmed - SkinWise</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #0f766e, #0d9488); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .logo { font-size: 28px; font-weight: bold; margin-bottom: 10px; }
    .content { background: white; padding: 30px; border: 1px solid #e5e7eb; }
    .footer { background: #f8fafc; padding: 20px; text-align: center; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
    .appointment-card { background: #ecfdf5; border: 2px solid #10b981; padding: 20px; margin: 20px 0; border-radius: 8px; text-align: center; }
    .preparation { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 4px; }
    .payment-details { background: #f1f5f9; padding: 15px; border-radius: 6px; margin: 15px 0; }
    .reference { font-family: monospace; background: #f3f4f6; padding: 8px; border-radius: 4px; display: inline-block; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">SkinWise</div>
      <p style="margin: 0; opacity: 0.9;">Dermatologist Consultations</p>
    </div>
    
    <div class="content">
      <h1 style="color: #0f766e; margin-top: 0;">🩺 Your Dermatologist Appointment is Confirmed!</h1>
      
      <p>Hello ${e.patientName},</p>
      
      <p>Great news! Your payment has been processed and your 15-minute consultation with a board-certified dermatologist has been confirmed.</p>
      
      <div class="appointment-card">
        <h2 style="color: #059669; margin-top: 0;">📅 Appointment Details</h2>
        <p style="font-size: 18px; margin: 10px 0;"><strong>Date:</strong> ${t}</p>
        <p style="font-size: 18px; margin: 10px 0;"><strong>Time:</strong> ${e.appointmentTime}</p>
        <p style="font-size: 16px; margin: 10px 0;"><strong>Duration:</strong> 15 minutes</p>
        <p style="font-size: 14px; margin: 10px 0; color: #6b7280;">Online Video Consultation</p>
      </div>
      
      <div class="preparation">
        <h3 style="margin-top: 0; color: #d97706;">🔔 Important: Video Call Link Coming Soon</h3>
        <p style="margin-bottom: 0;"><strong>We'll send you the video call link and detailed instructions 24 hours before your appointment.</strong> Please make sure to check your email (including spam folder) closer to your appointment date.</p>
      </div>
      
      <h3 style="color: #0f766e;">📋 How to Prepare</h3>
      <ul>
        <li><strong>Internet & Camera:</strong> Test your internet connection and camera/microphone</li>
        <li><strong>Lighting:</strong> Choose a well-lit room for the video call</li>
        <li><strong>Photos:</strong> Have any relevant photos of your skin concern ready to show</li>
        <li><strong>Medical History:</strong> Prepare information about current medications and allergies</li>
        <li><strong>Questions:</strong> Write down your questions to make the most of your 15 minutes</li>
      </ul>
      
      <div class="payment-details">
        <h3 style="margin-top: 0;">Payment Details</h3>
        <p><strong>Service:</strong> 15-minute dermatologist consultation</p>
        <p><strong>Amount Paid:</strong> ${e.currency} ${e.amount}</p>
        <p><strong>Booking Date:</strong> ${e.bookingDate}</p>
        <p><strong>Reference:</strong> <span class="reference">${e.sessionId}</span></p>
      </div>
      
      <p><strong>Need to reschedule?</strong> Please contact us at least 24 hours in advance.</p>
      
      <p>We look forward to helping you with your skin health concerns!</p>
      
      <p>Best regards,<br>The SkinWise Medical Team</p>
    </div>
    
    <div class="footer">
      <p style="margin: 0; color: #6b7280; font-size: 14px;">
        This email was sent to ${e.customerEmail}<br>
        SkinWise - Professional Dermatologist Consultations<br>
        Support: support@skinwise.com | Emergency: Call your local healthcare provider
      </p>
    </div>
  </div>
</body>
</html>
  `}(e),text:function(e){let t=new Date(`${e.appointmentDate}T${e.appointmentTime}`).toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});return`
SkinWise - Dermatologist Appointment Confirmed

Hello ${e.patientName},

Your dermatologist consultation has been confirmed!

APPOINTMENT DETAILS:
Date: ${t}
Time: ${e.appointmentTime}
Duration: 15 minutes
Type: Online Video Consultation

IMPORTANT: We'll send you the video call link 24 hours before your appointment.

HOW TO PREPARE:
- Test your internet connection and camera
- Choose a well-lit room for the video call
- Have photos of your skin concern ready
- Prepare your medical history and current medications
- Write down questions for the dermatologist

PAYMENT DETAILS:
Service: 15-minute dermatologist consultation
Amount Paid: ${e.currency} ${e.amount}
Booking Date: ${e.bookingDate}
Reference: ${e.sessionId}

Need to reschedule? Contact us at least 24 hours in advance.

Best regards,
The SkinWise Medical Team

---
This email was sent to ${e.customerEmail}
SkinWise - Professional Dermatologist Consultations
Support: support@skinwise.com
  `}(e)});if(n)throw console.error("❌ Failed to send appointment confirmation email:",n),n;return console.log("✅ Appointment confirmation email sent successfully:",t?.id),{success:!0,messageId:t?.id}}catch(e){return console.error("❌ Error sending appointment confirmation email:",e),{success:!1,error:e}}}async function D(e){try{console.log("\uD83D\uDCE7 Sending test email to:",e);let{data:t,error:n}=await T.emails.send({from:"SkinWise <noreply@skinwise.com>",to:[e],subject:"\uD83E\uDDEA Test Email - SkinWise Email System",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #0f766e;">✅ Email System Test Successful!</h1>
          <p>This is a test email to confirm that the SkinWise email system is working correctly.</p>
          <p><strong>Time sent:</strong> ${new Date().toLocaleString()}</p>
          <p>If you received this email, the integration is working perfectly!</p>
          <p>Best regards,<br>The SkinWise Development Team</p>
        </div>
      `,text:"SkinWise Email System Test - This email confirms that the email system is working correctly."});if(n)throw console.error("❌ Failed to send test email:",n),n;return console.log("✅ Test email sent successfully:",t?.id),{success:!0,messageId:t?.id}}catch(e){return console.error("❌ Error sending test email:",e),{success:!1,error:e}}}},35860:(e,t,n)=>{n.d(t,{O5:()=>a,hb:()=>s,tD:()=>o});let r=new Map,i={payment:{requests:3,windowMs:6e4},checkout:{requests:5,windowMs:3e5},email:{requests:2,windowMs:6e4},"test-email":{requests:1,windowMs:3e5},upload:{requests:10,windowMs:6e4},api:{requests:30,windowMs:6e4},auth:{requests:5,windowMs:3e5},webhook:{requests:100,windowMs:6e4}};async function s(e,t="api"){let n=function(e){let t=e.headers.get("x-forwarded-for"),n=e.headers.get("x-real-ip"),r=e.headers.get("cf-connecting-ip"),i=t?.split(",")[0]?.trim()||n||r||e.ip||"unknown";return`ip:${i}`}(e),s=i[t],o=Date.now(),a=`${t}:${n}`;.01>Math.random()&&function(){let e=Date.now();for(let[t,n]of r.entries())e>n.resetTime&&r.delete(t)}();let l=r.get(a);if((!l||o>l.resetTime)&&(l={count:0,resetTime:o+s.windowMs}),l.count>=s.requests){let e=Math.ceil((l.resetTime-o)/1e3);return{success:!1,limit:s.requests,remaining:0,resetTime:l.resetTime,retryAfter:e}}return l.count++,r.set(a,l),{success:!0,limit:s.requests,remaining:s.requests-l.count,resetTime:l.resetTime}}function o(e){let t=new Headers({"Content-Type":"application/json"});return t.set("X-RateLimit-Limit",e.limit.toString()),t.set("X-RateLimit-Remaining",e.remaining.toString()),t.set("X-RateLimit-Reset",new Date(e.resetTime).toISOString()),e.retryAfter&&t.set("Retry-After",e.retryAfter.toString()),new Response(JSON.stringify({error:"Too Many Requests",message:`Rate limit exceeded. Try again in ${e.retryAfter} seconds.`,retryAfter:e.retryAfter}),{status:429,headers:t})}function a(e,t,n){let r=new Date().toISOString();console.warn(`🚨 RATE LIMIT VIOLATION [${r}]`,{type:t,clientId:n,userAgent:e.headers.get("user-agent")||"unknown",referer:e.headers.get("referer")||"none",url:e.url,method:e.method})}}};